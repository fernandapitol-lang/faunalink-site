# FaunaLink — Pacote FULL

Conteúdo completo para deploy privado via GitHub Pages + Cloudflare Access.
Consulte README-DEPLOY.md para passos de deploy.
