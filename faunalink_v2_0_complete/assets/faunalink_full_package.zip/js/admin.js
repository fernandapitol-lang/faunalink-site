// admin.js
document.getElementById('loginBtn')?.addEventListener('click', () => {
  alert('Login simulado. Em produção use Cloudflare Access.');
});
document.getElementById('generatePdf')?.addEventListener('click', () => {
  if (window.generatePdfReport) window.generatePdfReport({ title:'Relatório FaunaLink — Admin' });
  else alert('jsPDF não carregado.');
});
document.getElementById('downloadZip')?.addEventListener('click', () => {
  window.location.href = '/assets/faunalink_full_package.zip';
});
