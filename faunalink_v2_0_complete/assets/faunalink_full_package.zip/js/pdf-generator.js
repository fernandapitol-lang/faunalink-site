// pdf-generator.js - uses jsPDF + autotable if available
window.generatePdfReport = function(opts){
  const title = opts?.title || 'Relatório FaunaLink';
  if (!window.jspdf) { alert('jsPDF não disponível.'); return; }
  const doc = new window.jspdf.jsPDF();
  doc.setFontSize(18);
  doc.text(title, 14, 22);
  doc.setFontSize(12);
  doc.text('Gerado em: ' + new Date().toISOString(), 14, 30);
  // autoTable if available
  if (window.jspdf && window.jspdf.autoTable) {
    window.jspdf.autoTable(doc, { head: [['ID','Espécie','Observador']], body: [[1,'Macaco-prego','Ana']] });
  }
  doc.save('relatorio-faunalink.pdf');
};
